<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
   function showDashboard(){
       return view('backend.dashboard');
   }
   function showMIS(){
       return view('backend.mis');
   }
}
