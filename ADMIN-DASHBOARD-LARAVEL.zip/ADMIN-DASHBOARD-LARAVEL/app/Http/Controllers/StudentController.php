<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function studentApi(){
        $student = Student::orderBy('id','DESC')->get();
        return Datatables::of($student)->addColumn("action", function($student){
            return "<div class='d-flex justify-content-center'>
                    <button onclick='editStudent($student->id)' class='btn m-1 btn-success btn-sm'><i class='fas fa-pen'></i>
                    </button> 
                    <button onclick='deleteStudent($student->id)' class='btn btn-danger m-1 btn-sm'><i class='fas fa-times'></i></button> 
                </div>";
        })->addIndexColumn()->toJson();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputs = $request->all();
        $validate = Validator::make($inputs, [
            'name'=>'required',
            'mobile'=>'required|numeric|unique:students'
        ] );

        if($validate->fails()){
            return response()->json([
                'title'=>'Error!',
                'message'=>$validate->messages()->all()[0],
                'icon'=>'error',
            ]);
        }

        Student::create(['name'=>$inputs['name'], 'mobile'=>$inputs['mobile']]);

        return response()->json([
            'title'=>'Success!',
            'message'=>'Data saved successfully!',
            'icon'=>'success',
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return Student::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $student = Student::find($id);

        $inputs = $request->all();
        $validate = Validator::make($inputs, [
            'name'=>'required',
            'mobile'=>'required'
        ] );

        if($validate->fails()){
            return response()->json([
                'title'=>'Error!',
                'message'=>$validate->messages()->all()[0],
                'icon'=>'error',
            ]);
        }

        $student->name = $inputs['name'];
        $student->mobile = $inputs['mobile'];
        $student->save();

        return response()->json([
            'title'=>'Success!',
            'message'=>'Data updated successfully!',
            'icon'=>'success',
        ]);
 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Student::destroy($id);
        return response()->json([
            'title'=>'Success!',
            'message'=>'Data deleted successfully!',
            'icon'=>'success',
        ]);        
    }
}
