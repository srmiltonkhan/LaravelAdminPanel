<div class="side-menu">
    <div class="organization-logo">
        <i class = "fab fa-apple"></i>
        <span>KYAMCH</span>
    </div>

    <ul>
        <li><a href="<?php echo e(url('/')); ?>"><i class="fas fa-tachometer-alt"></i>DASHBOARD</a></li>
        <li><a href="<?php echo e(url('mis')); ?>"> <i class="fas fa-laptop"></i> MIS</a></li>
    </ul>
</div>
<?php /**PATH E:\KYAMCHSERVER\www\Office\ADMIN-DASHBOARD-LARAVEL\resources\views/backend/layout/side_menu.blade.php ENDPATH**/ ?>