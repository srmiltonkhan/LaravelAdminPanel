

<?php $__env->startSection('title','Dashboard'); ?>


<?php $__env->startSection('content'); ?>

<div class="content-header">
    <h4>Dashboard</h4>
</div>
<div class="content-body">
    body
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KYAMCHSERVER\www\Office\ADMIN-DASHBOARD-LARAVEL\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>