<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('asset/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/vendor/datatables/css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/vendor/fontAwesome/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/backend/admin.css')); ?>">


</head>
<body>
 <div class="dashboard-container">
    <?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <?php echo $__env->make('backend.layout.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



     <div class="main-content">
         
     
    <?php echo $__env->yieldContent('content'); ?>


     </div>


     <?php echo $__env->make('backend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </div>   
 <script src="<?php echo e(asset('asset/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(asset('asset/vendor/js/jquery-3.6.0.min.js')); ?>"></script>
 <script src="<?php echo e(asset('asset/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
 <script src="<?php echo e(asset('asset/vendor/datatables/js/dataTables.bootstrap5.min.js')); ?>"></script>
 <script src="<?php echo e(asset('asset/vendor/sweetallert/sweetalert2@11.js')); ?>"></script>

 <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH E:\KYAMCHSERVER\www\Office\ADMIN-DASHBOARD-LARAVEL\resources\views/backend/layout/master.blade.php ENDPATH**/ ?>