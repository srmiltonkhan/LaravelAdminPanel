<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('asset/vendor/fontAwesome/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/backend/admin.css')); ?>">

</head>
<body>
 <div class="dashboard-container">
    <?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <?php echo $__env->make('backend.layout.side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



     <div class="main-content">
         
     
    <?php echo $__env->yieldContent('content'); ?>


     </div>


     <?php echo $__env->make('backend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </div>   
</body>
</html><?php /**PATH E:\KYAMCHSERVER\www\Office\ADMIN-DASHBOARD-LARAVEL\resources\views/backend/layout/master.blade.php ENDPATH**/ ?>