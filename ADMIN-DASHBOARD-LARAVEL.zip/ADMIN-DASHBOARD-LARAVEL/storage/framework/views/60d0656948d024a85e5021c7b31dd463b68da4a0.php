

<?php $__env->startSection('title','MIS'); ?>


<?php $__env->startSection('content'); ?>

<h1>MIS</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KYAMCHSERVER\www\Office\ADMIN-DASHBOARD-LARAVEL\resources\views/backend/mis.blade.php ENDPATH**/ ?>