
<?php $__env->startSection('title','Dashboard'); ?>


test
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KYAMCHSERVER\www\Office\ADMIN\ADMIN-DASHBOARD\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>