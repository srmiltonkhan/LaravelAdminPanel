@extends('backend.layout.master')

@section('title','Dashboard')


@section('content')

<div class="content-header">
    <h4>Dashboard</h4>
</div>
<div class="content-body">
    body
</div>

@endsection


