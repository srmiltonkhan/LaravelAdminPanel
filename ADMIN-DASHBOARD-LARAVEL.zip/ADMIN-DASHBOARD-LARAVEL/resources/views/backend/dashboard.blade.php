@extends('backend.layout.master')

@section('title','Dashboard')


@section('content')

<div class="content-header">
    <h1>Dashboard</h1>
</div>
<div class="content-body">
    body
</div>

@endsection


