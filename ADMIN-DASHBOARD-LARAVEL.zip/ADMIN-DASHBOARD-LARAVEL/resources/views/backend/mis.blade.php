@extends('backend.layout.master')

@section('title','MIS')


@section('content')

<div class="content-header">
    <h4>MIS</h4>
</div>
<div class="content-body">
    body


@endsection

