@extends('backend.layout.master')

@section('title','MIS')


@section('content')

<h1>MIS</h1>

@endsection