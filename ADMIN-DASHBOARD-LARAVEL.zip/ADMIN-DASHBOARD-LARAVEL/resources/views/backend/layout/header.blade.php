<div class="header">
    <div class="header-content">
        <div class="toggle-btn">
            <i class="fas fa-bars"></i>
        </div>
        <div class="welcome-dashboard">
            <marquee behavior="" direction=""><h5>Welcome to our Dashboard</h5></marquee>
        </div>
        <div class="profile-info">
            <div><img src="" onerror="this.onerror=null;this.src='{{asset('asset/files/static/user_img/default_user_image.png')}}'" width="30" height="30"></div>
            <div class="user-name">Milton Hosssain</div>
            <div><i class="fas fa-chevron-down profile_dropdown_icon"></i></div>
        </div>
    </div>
    <div id="profile-dropdown" class="profile-dropdown-content">
        <ul>
            <li><i class="fas fa-user"></i><a href="">Profile</a></li>
            <li><i class="fas fa-sign-out-alt"></i><a href="">Change Password</a></li>
            <li><i class="fas fa-sign-out-alt"></i><a href="">Logout</a></li>
        </ul>
    </div>
</div>

<script>
     window.onload = function(){

        document.addEventListener('click', function(event){ 
            let drop =  document.getElementById('profile-dropdown');
            if(drop.style.display === 'block'){
                drop.style.display = 'none'
            }else{
                if(event.target.matches('.profile_dropdown_icon')){
                    let drop =  document.getElementById('profile-dropdown');

                    if(drop.style.display === 'block'){
                        drop.style.display = 'none'
                    }else{
                        drop.style.display = 'block'
                    }
                } 
            }
        });
     }
    </script>


        