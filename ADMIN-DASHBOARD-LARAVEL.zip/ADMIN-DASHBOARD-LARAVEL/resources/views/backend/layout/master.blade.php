<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{asset('asset/vendor/fontAwesome/css/all.css')}}">
    <link rel="stylesheet" href="{{asset('asset/css/backend/admin.css')}}">

</head>
<body>
 <div class="dashboard-container">
    @include('backend.layout.header')




    @include('backend.layout.side_menu')



     <div class="main-content">
         
     
    @yield('content')


     </div>


     @include('backend.layout.footer')
 </div>   
 <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
</body>
</html>