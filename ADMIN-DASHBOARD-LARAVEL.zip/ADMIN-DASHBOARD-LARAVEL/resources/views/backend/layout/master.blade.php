<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{asset('asset/vendor/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('asset/vendor/datatables/css/dataTables.bootstrap5.min.css')}}">
    <link rel="stylesheet" href="{{asset('asset/vendor/fontAwesome/css/all.css')}}">
    <link rel="stylesheet" href="{{asset('asset/css/backend/admin.css')}}">


</head>
<body>
 <div class="dashboard-container">
    @include('backend.layout.header')




    @include('backend.layout.side_menu')



     <div class="main-content">
         
     
    @yield('content')


     </div>


     @include('backend.layout.footer')
 </div>   
 <script src="{{asset('asset/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
 <script src="{{asset('asset/vendor/js/jquery-3.6.0.min.js')}}"></script>
 <script src="{{asset('asset/vendor/datatables/js/jquery.dataTables.min.js')}}"></script>
 <script src="{{asset('asset/vendor/datatables/js/dataTables.bootstrap5.min.js')}}"></script>
 <script src="{{asset('asset/vendor/sweetallert/sweetalert2@11.js')}}"></script>

 @yield('script')
</body>
</html>