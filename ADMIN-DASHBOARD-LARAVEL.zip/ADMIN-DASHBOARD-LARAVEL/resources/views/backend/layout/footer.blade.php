<div class="footer">
    <div class="copy-right">Copyright © 2005-2021 All Rights Reserved by KYAMCH</div>
    <div class="developer-info">DESIGN AND DEVELOPED BY KYAMCH IT DEPARTMENT</div>
</div>