<div class="side-menu">
    <div class="organization-logo">
        <i class = "fab fa-apple"></i>
        <span>KYAMCH</span>
    </div>

    <ul>
        <li><a href="{{url('/')}}"><i class="fas fa-tachometer-alt"></i>DASHBOARD</a></li>
        <li><a href="{{url('mis')}}"> <i class="fas fa-laptop"></i> MIS</a></li>
        <li><a href="{{url('crud')}}"> <i class="fas fa-table"></i> CRUD</a></li>
    </ul>
</div>
