@extends('backend.layout.master')

@section('title','CRUD')


@section('content')

<div class="content-header">
    <h4>CRUD</h4>
</div>
<div class="content-body">
<div class="card">
        <div class="card-header">
            <div class="card-header-container">
                <div class="card-title">Title</div>
                <div class="card-add-btn">
                    <button type="button" id="add_btn" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#crudModal">Add <i class="fas fa-plus"></i></button>
                </div>
            </div>
        </div>
        <div class="card-body">
        <table class="table table-striped table-light table-sm" id="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
  
<!-- The Modal -->
<div class="modal fade" id="crudModal">
  <div class="modal-dialog">
    <div class="modal-content">
    <form method="POST">
        @csrf
      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="row">
            <div class="col-sm-3"><label for="name" class="float-sm-end">Name:</label> </div>
            <div class="col-sm-9"><input type="text" name="name" id="name" class="form-control form-control-sm"></div>
        </div>
        <div class="row mt-2">
            <div class="col-sm-3"><label for="mobile" class="float-sm-end">Mobile:</label> </div>
            <div class="col-sm-9"><input type="text" name="mobile" id="mobile" class="form-control form-control-sm"></div>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
      <input type="hidden" name="editId" id="editId">
      <input type="hidden" name="action" id="action" />
      <input type="submit" name="action_submit" id="action_submit" class="btn btn-sm btn-primary rounded-pill" style="width: 80px">
      <input type="button" value="Close" data-bs-dismiss="modal" class="btn btn-sm btn-danger rounded-pill" style="width: 80px">
      </div>
      </form>
    </div>
  </div>
</div>    

</div>
@endsection




@section('script')
<script>
var table = $("#table").DataTable({
    processing:true,
    serverSide:true,
    ajax:"{{ url('studentApi') }}",
    columns: [
        {data:"DT_RowIndex"},
        {data: "name"},
        {data: "mobile"},
        {data: "action"},
    ]
});
$("#add_btn").click(function(){
    $("#crudModal form")[0].reset();
    $(".modal-title").text("Add Data");
    $("#action_submit").val("Save");
})
$("#crudModal form").on("submit", function(e){
    e.preventDefault();
    let  url=  `{{ url('studenStore') }}`;
    let type = "POST";
    let data = $("#crudModal form").serialize();
    

    if($('#action_submit').val() == "Update"){
        let id = $("#editId").val();
        url = `{{ url('studentUpdate') }}/${id}`;
        data += "&_method=PATCH"
    }
    $.ajax({
        url: url,
        type: type,
        data: data,
        success: function(res){
            Swal.fire({
                title: res.title,
                text: res.message,
                icon: res.icon,
                confirmButtonText:"Close"
            });
            if(res.title!=="Error!"){
                $("#crudModal").modal("hide");
                table.ajax.reload();
            }
            
        },
        error: function(err){
            console.log(err)
            Swal.fire({
                title: "Error",
                text: "Unknown error",
                icon: "error",
                confirmButtonText:"Close"
            })
        }
    });
});

function editStudent(id){
    $('#crudModal form')[0].reset();
    $(".modal-title").html("Edit Data");
    $("#action_submit").val("Update");
    $.ajax({
        url: `{{url('studentEdit')}}/${id}`,
        type: "GET",
        dataType:"JSON",
        success: function(res){
            console.log(res)
            $("#crudModal").modal("show");
            $("#name").val(res.name);
            $("#mobile").val(res.mobile);
            $("#editId").val(res.id);
        },
        error: function(err){
            console.log(err);
        }
    });
}

// if($('#action_submit').val() == "Update"){
//     $("#crudModal form").on("submit", function(e){
//     e.preventDefault();
//     let id = $("#editId").val();
//             $.ajax({
//                 url:`{{ url('studentUpdate') }}/${id}`,
//                 type: "POST",
//                 data: $("#crudModal form").serialize(),
//                 success: function(res){
//                     console.log(res);
//                     Swal.fire({
//                         title: res.title,
//                         text: res.message,
//                         icon: res.icon,
//                         confirmButtonText:"Close"
//                     });
//                     $("#crudModal").modal("hide")
//                     table.ajax.reload();
//                 },
//                 error: function(err){
//                     console.log(err)
//                     Swal.fire({
//                         title: "Error",
//                         text: "Unknown error",
//                         icon: "error",
//                         confirmButtonText:"Close"
//                     })
//                 }
//             })
//     })
// }

function deleteStudent(id){
    Swal.fire({
        title: "Delete?",
        text: "Are you sure you want to delete?",
        showCancelButton: true,
        confirmButtonText: "Yes, Delete",
        cancelButtonText: "No, go back",
    }).then(function(e){
                if(e.value===true){
                    let csrf_token = $('meta[name="csrf-token"]').attr('content');
                    $.ajax({
                        url: `{{url('studentDelete')}}/${id}`,
                        type: "POST",
                        data: {'_token': csrf_token},
                        success: function(res){
                            console.log(res);
                            Swal.fire({
                                title: res.title,
                                text: res.message,
                                icon: res.icon,
                                confirmButtonText:"Close"
                            });
                            table.ajax.reload();
                        },
                        error: function(err){
                            console.log(err)
                            Swal.fire({
                                title: "Error",
                                text: "Unknown error",
                                icon: "error",
                                confirmButtonText:"Close"
                            })
                        }
                    })
                }
            });
}

</script>
@endsection